package com.example.studySpringboot0001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudySpringboot0001ApplicationTests {

	@Test
	void contextLoads() {
	}

}
